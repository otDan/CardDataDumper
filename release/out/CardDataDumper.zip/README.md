<img align="right" src="https://github.com/otDan/CardDataDumper/blob/master/release/icon-full.png?raw=true" height="190" hspace="20"/>

# CardDataDumper for [ROUNDS](https://store.steampowered.com/app/1557740/ROUNDS/)
Example description for rounds mod

## Installation

<a href="https://rounds.thunderstore.io/package/otDan/CardDataDumper">
    <img align="right" src="https://badgen.net/https/git-hub-badge-data.npkn.net/thunderstore-downloads-request/CardDataDumper?icon=https://gcdn.thunderstore.io/static/ts/thunderstore-logomark-white.svg" hspace="50"/>
</a>

- Thunderstore: 
  - https://rounds.thunderstore.io/package/otDan/CardDataDumper

<a href="https://github.com/otDan/CardDataDumper/releases">
    <img align="right" src="https://badgen.net/github/assets-dl/otDan/CardDataDumper?icon=git&color=blue" hspace="50"/>
</a>

- Manual: 
  - https://github.com/otDan/CardDataDumper/releases
    
## Example
Insert gif or link to demo

## Versions
- 1.0.0
  - Example Feature

<p align="left"> 
    <a href="https://www.paypal.com/paypalme/otdan">
        <img align="right" src="https://raw.githubusercontent.com/aha999/DonateButtons/master/Paypal.png" 
        height="65" 
        style="margin:-15px 25px"/>
    </a>
</p>

## Author
- [@otDan](https://www.github.com/otdan)

## License
[MIT](https://choosealicense.com/licenses/mit/)
